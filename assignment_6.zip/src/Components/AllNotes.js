import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { removeNote, updateNote } from '../Redux/action';
import { useNavigate } from 'react-router-dom';
import './style.css';

export default function AllNotes() {
  const notes = useSelector((state) => state.notes);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const [editNoteId, setEditNoteId] = useState(null);
  const [editTitle, setEditTitle] = useState('');
  const [editContent, setEditContent] = useState('');

  const handleEditNote = (note) => {
    setEditNoteId(note.id);
    setEditTitle(note.title);
    setEditContent(note.content);
  };

  const handleUpdateNote = (e) => {
    e.preventDefault();
    dispatch(updateNote(editNoteId, editTitle, editContent));
    setEditNoteId(null);
    setEditTitle('');
    setEditContent('');
  };

  const handleDeleteNote = (id) => {
    dispatch(removeNote(id));
  };

  return (
    <>
      <nav>
        <h1>My Notes</h1>
        <button className="button-29" role="button" onClick={() => navigate('/')}>
          Home
        </button>
      </nav>
      <main>
        <div className="notes-container">
          {notes.map((note) => (
            <div className="card" key={note.id}>
              <div className="card-body">
                {editNoteId === note.id ? (
                  <form onSubmit={handleUpdateNote}>
                    <div className="form-group">
                      <label htmlFor="editTitle">Title:</label>
                      <input
                        type="text"
                        className="form-control"
                        id="editTitle"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="editContent">Content:</label>
                      <textarea
                        className="form-control"
                        id="editContent"
                        rows="3"
                        value={editContent}
                        onChange={(e) => setEditContent(e.target.value)}
                      ></textarea>
                    </div>
                    <button type="submit" className="btn btn-primary">
                      Save
                    </button>
                    <button type="button" className="btn btn-secondary" onClick={() => setEditNoteId(null)}>
                      Cancel
                    </button>
                  </form>
                ) : (
                  <>
                    <h5 className="card-title">{note.title}</h5>
                    <p className="card-text">{note.content}</p>
                    <div className="card-buttons">
                      <button className="btn btn-danger" onClick={() => handleDeleteNote(note.id)}>
                        Delete
                      </button>
                      <button className="btn btn-secondary" onClick={() => handleEditNote(note)}>
                        Edit
                      </button>
                    </div>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </main>
      <footer>
        <p>&copy; 2023  Notes App by AK. All rights reserved.</p>
      </footer>
    </>
  );
}
