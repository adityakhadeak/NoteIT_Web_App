import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { addNote } from '../Redux/action';
import './form.css';

const NotesForm = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSubmission = (e) => {
    e.preventDefault();
    dispatch(addNote(title, content));
    setTitle('');
    setContent('');
    navigate('/allNotes');
  }

  return (
    <div className='notesFormContainer'>
      <div className='notesForm'>
        <h3 className='notesForm__title'>React Notes App</h3>
        <form onSubmit={handleSubmission}>
          <div className='notesForm__inputGroup'>
            <label className='notesForm__label'>Title:</label>
            <input className='notesForm__input' type='text' name='title' value={title} placeholder='Enter title' onChange={(e) => setTitle(e.target.value)} required />
          </div>
          <div className='notesForm__inputGroup'>
            <label className='notesForm__label'>Content:</label>
            <textarea className='notesForm__input' name='content' value={content} placeholder='Enter content' onChange={(e) => setContent(e.target.value)} required />
          </div>
          <button className='notesForm__button' role='button'>Add Note</button>
        </form>
        <div className='notesForm__footer'>
          <Link to='/allNotes' className='notesForm__link'>View All Notes</Link>
        </div>
      </div>
    </div>
  )
}

export default NotesForm;
